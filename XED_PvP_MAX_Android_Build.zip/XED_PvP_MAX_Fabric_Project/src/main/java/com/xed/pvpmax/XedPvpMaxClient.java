package com.xed.pvpmax;

import net.fabricmc.api.ClientModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class XedPvpMaxClient implements ClientModInitializer {
    public static final String MOD_ID = "xed_pvp_max";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitializeClient() {
        LOGGER.info("XED PvP MAX core initialized. Feature modules will be added in later builds.");
    }
}
