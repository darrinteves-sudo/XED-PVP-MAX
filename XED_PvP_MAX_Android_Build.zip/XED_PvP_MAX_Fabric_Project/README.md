# XED PvP MAX — Fabric source project

This is the initial client-side Fabric mod scaffold for Minecraft 1.21.11. It currently provides a loadable mod core and startup log only; it does **not** yet recreate the visual features from the reference video.

## Build requirements
- JDK 21
- Gradle 8.14.3 or a compatible Gradle installation
- Internet access to resolve Fabric/Minecraft build dependencies

## Build
From this folder, run:

```bash
gradle build
```

The distributable JAR will be in `build/libs/` (choose the JAR without `-sources` or `-dev` in its name).

## Install
Copy the built JAR into the `mods` folder of a Minecraft 1.21.11 Fabric profile. This initial core requires Fabric Loader 0.18.1+ and Fabric API 0.141.1+1.21.11.

## Important
The JAR must be built with Gradle; renaming the ZIP to `.jar` will not work. MobileGlues compatibility is not yet verified. Test with a backup profile and add other mods gradually.

## Build in the cloud from Android (no Termux)
This project includes `.github/workflows/build.yml`. Upload the project contents to a GitHub repository, open the repository's **Actions** tab, choose **Build XED PvP MAX**, and press **Run workflow**. When the run finishes successfully, open the run's **Artifacts** section and download `xed-pvp-max-jars`. Extract it to get the `.jar`.
